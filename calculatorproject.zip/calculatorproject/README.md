# CalculatorProject
  Java Eclipse Basic Calculator GUI

# Things used in project 
  Three different classes MyCalculator class which is the main class, Number class and
  Calculation class for usablity and keeping code split up for better practice.

# Description
  GUI application create with Eclipse that is split into three classes MyCalculator, 
  Calculation, and Numbers for usability. Where MyCalculator class is the interface, 
  the Calculation class works with calculation and the Numbers class deals with the press 
  of each number and giving them values.
  
 # Screenshot
   ![Screenshot](CalculatorGUI.PNG)
   
 # IDE USED
   Eclipse Java EE IDE version: Mars.2 (4.5.2)
